"""For backwards compatiblity."""
from langchain.utilities.serpapi import SerpAPIWrapper

__all__ = ["SerpAPIWrapper"]
